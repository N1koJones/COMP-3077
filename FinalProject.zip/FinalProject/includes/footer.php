<!-- filepath: includes/footer.php -->
<footer>
    <p>
        &copy; 2025 Niko's Manga and Manwha WebStore. All rights reserved.
        <br>
        "Keep creating cool shit!" ~ Niko Jones
    </p>
</footer>
</body>
</html>